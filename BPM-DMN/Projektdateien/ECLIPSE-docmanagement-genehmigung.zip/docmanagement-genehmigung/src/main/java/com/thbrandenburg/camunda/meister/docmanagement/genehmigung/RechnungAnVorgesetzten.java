package com.thbrandenburg.camunda.meister.docmanagement.genehmigung;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

/**
 * service implementation
 * class as a BPMN 2.0 Service Task delegate.
 */
public class RechnungAnVorgesetzten implements JavaDelegate {
	   
  public void execute(DelegateExecution execution) throws Exception {
    
    // Web service Aufruf um Rechnung an Vorgesetzten zu senden
	  
	  
  }

}
